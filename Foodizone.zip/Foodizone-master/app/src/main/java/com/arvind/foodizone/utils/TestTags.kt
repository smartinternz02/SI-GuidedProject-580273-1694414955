package com.arvind.foodizone.utils

object TestTags {
    const val STANDARD_TEXT_FIELD = "standard_text_field"
    const val PASSWORD_TOGGLE = "password_toggle"
}
package com.arvind.foodizone.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class FoodizoneApp : Application() {

}
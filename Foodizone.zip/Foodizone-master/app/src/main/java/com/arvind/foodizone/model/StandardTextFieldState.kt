package com.arvind.foodizone.model

data class StandardTextFieldState(
    val text: String = "",
    val error: String = ""
)
